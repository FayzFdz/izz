'use strict';
const { handleApiRequest } = require('../backend');
module.exports = function handler(req, res) {
  return handleApiRequest(req, res);
};
