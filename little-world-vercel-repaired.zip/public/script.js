/* A Little World — standalone HTML/CSS/JavaScript experience.
   Music is streamed through official YouTube embeds. Browser autoplay policies
   may require the visitor to activate the radio once. */
(function () {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const clone = (obj) => JSON.parse(JSON.stringify(obj));
  const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  const videoIdFrom = (url) => {
    if (!url) return '';
    const match = String(url).match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?.*v=|embed\/|shorts\/))([\w-]{11})/i);
    return match ? match[1] : '';
  };
  const defaultData = {
    profile: {
      name: 'Muhamad Faiz Fakhriy Dzikrullah', nickname: '',
      intro: 'Just a little world of mine. Sebuah ruang untuk cerita, momen, dan lagu yang ingin disimpan.',
      bio: 'Not everything needs a big explanation. Some things are best understood through the moments we keep, the music we return to, and the little details that make a day feel like ours.',
      city: '', activity: '', interests: 'Music, little moments, photography',
      principle: 'Collecting moments, not perfection. Learning as I go, keeping the good things close.',
      email: '', instagram: '', photo: './assets/portrait.webp'
    },
    tracks: [
      { id: 'track-0', title: 'Multo', artist: 'Cup of Joe', album: 'Multo (single, 2024)', cover: 'https://i.scdn.co/image/ab67616d0000e1a3394048503e3be0e65e962638', spotify: 'https://open.spotify.com/track/4cBm8rv2B5BJWU2pDaHVbF', note: 'Lagu tentang perasaan yang menetap, bahkan saat seseorang atau sebuah kenangan sudah jauh. Melodi yang terasa seperti membuka kembali halaman lama.', source: 'https://www.youtube.com/watch?v=CcS1fsuT10M', vibe: 'NOSTALGIC', tags: ['nostalgic', 'longing', 'late night'] },
      { id: 'track-1', title: 'About You', artist: 'The 1975', album: 'Being Funny In A Foreign Language (2022)', cover: 'https://i.scdn.co/image/ab67616d0000e1a300702474f8e0e2b6155d48e3', spotify: 'https://open.spotify.com/track/3hEfpBHxgieRLz4t3kLNEg', note: 'Atmosfernya seperti mimpi yang samar: hangat, luas, dan sedikit melankolis. Cocok untuk mengenang seseorang tanpa harus menjelaskan semuanya.', source: 'https://www.youtube.com/watch?v=tGv7CUutzqU', vibe: 'DREAMY', tags: ['dreamy', 'reminiscing', 'midnight'] },
      { id: 'track-2', title: 'Nina', artist: '.Feast', album: 'Nina (single, 2024)', cover: 'https://i.scdn.co/image/ab67616d0000e1a339695d4c16489cdf60bef536', spotify: 'https://open.spotify.com/track/1zFaLYA10ImwEejge3F5nm', note: 'Sebuah pengingat tentang kasih sayang, jarak, dan harapan yang tetap dibawa. Lagu yang terasa personal dan penuh doa baik.', source: 'https://www.youtube.com/watch?v=iQo-8wx0l0Y', vibe: 'TENDER', tags: ['tender', 'hope', 'heartfelt'] },
      { id: 'track-3', title: 'everything u are', artist: 'Hindia', album: "Doves, '25 on Blank Canvas (2025 Spotify album listing)", cover: 'https://i.scdn.co/image/ab67616d0000e1a305898628baab6ef07a0a4d03', spotify: 'https://open.spotify.com/track/5WOSNVChcadlsCRiqXE45K', note: 'Tentang menerima seseorang sebagai dirinya sendiri. Nuansanya intim, seperti percakapan yang tak perlu dibuat sempurna.', source: 'https://www.youtube.com/watch?v=da4Xw2Kr79w', vibe: 'INTIMATE', tags: ['acceptance', 'warm', 'soft'] },
      { id: 'track-4', title: 'Yang Patah Tumbuh, Yang Hilang Berganti', artist: 'Banda Neira', album: 'Yang Patah Tumbuh, Yang Hilang Berganti (2016)', cover: 'https://i.scdn.co/image/ab67616d0000e1a37a173b7767ca05f9bb17464e', spotify: 'https://open.spotify.com/track/0hzIdk9dIvDablVS6UW7Vi', note: 'Lagu yang menenangkan tentang perubahan dan kesempatan untuk tumbuh lagi. Sebuah pengingat bahwa kehilangan bukan akhir dari cerita.', source: 'https://www.youtube.com/watch?v=fY8L4K30hDw', vibe: 'HOPEFUL', tags: ['hopeful', 'growth', 'healing'] }
    ],
    photos: [{ id: 'portrait-1', src: './assets/portrait.webp', caption: 'Foto profil', date: '', shape: 'portrait' }],
    education: []
  };

  let data = clone(defaultData);
  let baseData = clone(defaultData);
  let selectedIndex = 0;
  let activeSlide = 'home';
  let radioEnabled = localStorage.getItem('little-world-radio-off') !== '1';
  let playbackState = 'loading'; // loading | playing | paused | blocked | error
  let playbackMode = 'radio'; // radio | track
  let player = null;
  let ytReady = false;
  let currentLightboxIndex = 0;
  let toastTimer = null;
  let editorDraft = null;
  let pauseFallbackTimer = null;
  let programmaticLoad = false;
  let sessionRole = null;
  let sessionReady = false;
  let educationIndex = 0;
  let educationPaused = false;

  const shortName = (profile) => (profile.nickname || profile.name || 'little world').trim();
  const firstName = (profile) => shortName(profile).split(/\s+/)[0] || 'little';
  const normalizeData = (raw) => {
    const merged = clone(defaultData);
    if (raw && raw.profile) merged.profile = { ...merged.profile, ...raw.profile };
    if (Array.isArray(raw && raw.tracks) && raw.tracks.length) {
      merged.tracks = raw.tracks.map((track, index) => {
        const known = defaultData.tracks.find((item) => item.id === track.id || item.title.toLowerCase() === String(track.title || '').toLowerCase()) || {};
        return { ...known, ...track, id: track.id || `track-${index}-${Date.now()}`, tags: Array.isArray(track.tags) ? track.tags : (known.tags || ['favorite']) };
      });
    }
    if (Array.isArray(raw && raw.photos)) merged.photos = raw.photos;
    if (Array.isArray(raw && raw.education)) merged.education = raw.education.map((school, index) => ({ id: school.id || `school-${index}-${Date.now()}`, level: '', school: '', years: '', description: '', image: '', ...school }));
    if (!merged.tracks.length) merged.tracks = clone(defaultData.tracks);
    if (!Array.isArray(merged.photos)) merged.photos = [];
    return merged;
  };
  const saveToLocal = () => {
    try {
      localStorage.setItem('little-world-content-v2', JSON.stringify(data));
      return true;
    } catch (error) {
      showToast('Konten berubah untuk sesi ini, tetapi penyimpanan browser penuh. Ekspor konfigurasi agar tidak hilang.');
      console.warn('Local storage could not save the full config:', error);
      return false;
    }
  };
  const showToast = (message) => {
    const toast = $('#toast');
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('is-visible');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('is-visible'), 3200);
  };
  const setDockMessage = (message, show = true) => {
    const layer = $('#dockMessage');
    if (!layer) return;
    layer.innerHTML = `<span class="loader-ring"></span><span>${escapeHtml(message)}</span>`;
    layer.classList.toggle('is-hidden', !show);
  };
  const setPlaybackLabel = (label, state = playbackState) => {
    $('#dockStatus').textContent = label;
    $('#dockMode').textContent = playbackMode === 'radio' ? 'LITTLE WORLD RADIO' : 'YOUR SELECTED TRACK';
    $('.dock-indicator').classList.toggle('is-playing', state === 'playing');
    $('#dockPlay').textContent = state === 'playing' ? 'Ⅱ' : '▶';
    $('#dockPlay').setAttribute('aria-label', state === 'playing' ? 'Pause musik' : 'Putar musik');
    $('#soundLabel').textContent = radioEnabled ? 'RADIO ON' : 'RADIO OFF';
    $('#soundToggle').classList.toggle('is-off', !radioEnabled);
    $('#soundToggle').setAttribute('aria-pressed', String(radioEnabled));
  };
  const updateDockTrack = () => {
    if (!data.tracks.length) return;
    const track = data.tracks[selectedIndex] || data.tracks[0];
    $('#dockTitle').textContent = track.title || 'Untitled track';
    $('#dockArtist').textContent = track.artist || 'Unknown artist';
    $('#dockCover').src = track.cover || data.profile.photo || './assets/portrait.webp';
    $('#dockCover').alt = `Cover ${track.title || 'lagu'}`;
    $('#dockSpotify').onclick = () => window.open(track.spotify || track.source || '#', '_blank', 'noopener,noreferrer');
    $$('.track-card').forEach((card) => card.classList.toggle('is-playing', Number(card.dataset.index) === selectedIndex && playbackState === 'playing'));
  };
  const setTrackDisplay = () => {
    if (!data.tracks.length) return;
    updateDockTrack();
    $$('.track-card').forEach((card) => {
      const current = Number(card.dataset.index) === selectedIndex;
      card.classList.toggle('is-playing', current && playbackState === 'playing');
      const button = $('.cover-play', card);
      if (button && current && playbackState === 'playing') button.textContent = 'Ⅱ';
      else if (button) button.textContent = '▶';
    });
  };

  function renderProfile() {
    const p = data.profile;
    $$('[data-first-name]').forEach((el) => el.textContent = firstName(p).toLowerCase());
    $$('[data-profile-name]').forEach((el) => el.textContent = p.name || 'A little world');
    $$('[data-profile-short]').forEach((el) => el.textContent = shortName(p));
    $$('[data-profile-intro]').forEach((el) => el.textContent = p.intro || 'A little world of mine.');
    $$('[data-profile-bio]').forEach((el) => el.textContent = p.bio || 'A little archive of stories, moments, and melodies.');
    $$('[data-profile-principle]').forEach((el) => el.textContent = p.principle || 'Keep the good things close.');
    const photo = p.photo || './assets/portrait.webp';
    $('#heroPortrait').src = photo;
    $('#heroPortrait').alt = `Foto profil ${p.name || ''}`;
    $('#aboutFacts').innerHTML = [
      ['SONGS ON REPEAT', String(data.tracks.length).padStart(2, '0')],
      ['MEMORIES KEPT', String(data.photos.length).padStart(2, '0')],
      ['BASED IN', p.city || 'THE MOMENT']
    ].map(([label, value]) => `<div class="fact"><div class="fact-label">${escapeHtml(label)}</div><div class="fact-value">${escapeHtml(value)}</div></div>`).join('');
    const interests = String(p.interests || '').split(/[,\n]/).map((v) => v.trim()).filter(Boolean).slice(0, 8);
    $('#interestChips').innerHTML = (interests.length ? interests : ['Music', 'Little moments', 'Learning as I go']).map((v) => `<span class="interest-chip">${escapeHtml(v)}</span>`).join('');
    renderContact();
  }

  function renderContact() {
    const p = data.profile;
    const buttons = [];
    if (p.email) {
      buttons.push(`<a class="primary-cta" href="mailto:${escapeHtml(p.email)}"><span class="cta-icon">✉</span> Say hello <span class="cta-arrow">↗</span></a>`);
      buttons.push(`<button class="contact-secondary" type="button" id="copyEmail">Copy email <span>⧉</span></button>`);
    } else {
      buttons.push('<button class="primary-cta" type="button" id="contactAddEmail"><span class="cta-icon">✉</span> Add contact details <span class="cta-arrow">↗</span></button>');
    }
    if (p.instagram) buttons.push(`<a class="contact-secondary" href="${escapeHtml(p.instagram)}" target="_blank" rel="noopener noreferrer">Instagram <span>↗</span></a>`);
    $('#contactButtons').innerHTML = buttons.join('');
    $('#copyEmail')?.addEventListener('click', async () => {
      try { await navigator.clipboard.writeText(p.email); showToast('Alamat email disalin.'); }
      catch { showToast(`Email: ${p.email}`); }
    });
    $('#contactAddEmail')?.addEventListener('click', () => openEditor('profile'));
  }

  function renderTracks() {
    const query = ($('#trackSearch').value || '').trim().toLowerCase();
    const matches = data.tracks.map((track, index) => ({ track, index })).filter(({ track }) => `${track.title} ${track.artist} ${track.album || ''} ${(track.tags || []).join(' ')}`.toLowerCase().includes(query));
    $('#trackCount').textContent = `${String(data.tracks.length).padStart(2, '0')} TRACK${data.tracks.length === 1 ? '' : 'S'}`;
    if (!matches.length) {
      $('#trackGrid').innerHTML = '<div class="no-results">No songs found. Try another title or artist.</div>';
      return;
    }
    $('#trackGrid').innerHTML = matches.map(({ track, index }) => {
      const title = escapeHtml(track.title || 'Untitled track');
      const artist = escapeHtml(track.artist || 'Unknown artist');
      const cover = escapeHtml(track.cover || data.profile.photo || './assets/portrait.webp');
      const album = escapeHtml(track.album || 'A favorite track');
      const vibe = escapeHtml(track.vibe || (track.tags || ['FAVORITE'])[0] || 'FAVORITE');
      const selected = selectedIndex === index;
      return `<article class="track-card${selected && playbackState === 'playing' ? ' is-playing' : ''}" data-index="${index}">
        <div class="track-cover-wrap"><img src="${cover}" alt="Cover album ${title}" loading="lazy" onerror="this.src='./assets/portrait.webp'"/><span class="cover-index">SIDE ${String(index + 1).padStart(2, '0')}</span><button type="button" class="cover-play" data-play-track="${index}" aria-label="Putar ${title}">${selected && playbackState === 'playing' ? 'Ⅱ' : '▶'}</button></div>
        <div class="track-copy"><h3 class="track-title" title="${title}">${title}</h3><p class="track-artist">${artist}</p><p class="track-album">${album}</p></div>
        <div class="track-card-bottom"><span class="track-vibe">✳ ${vibe}</span><button type="button" class="track-details" data-detail-track="${index}">Details ↗</button></div>
      </article>`;
    }).join('');
    $$('[data-play-track]').forEach((button) => button.addEventListener('click', () => playTrack(Number(button.dataset.playTrack), 'track')));
    $$('[data-detail-track]').forEach((button) => button.addEventListener('click', () => openTrackDetail(Number(button.dataset.detailTrack))));
  }

  function renderGallery() {
    const photos = data.photos || [];
    $('#photoCount').textContent = String(photos.length).padStart(2, '0');
    const cards = photos.map((photo, index) => `<button class="gallery-card" type="button" data-photo-index="${index}" aria-label="Lihat ${escapeHtml(photo.caption || `foto ${index + 1}`)}"><img src="${escapeHtml(photo.src)}" alt="${escapeHtml(photo.caption || `Foto personal ${index + 1}`)}" loading="lazy" onerror="this.src='./assets/portrait.webp'"/><span class="gallery-number">FRAME ${String(index + 1).padStart(2, '0')}</span><span class="gallery-caption"><b>${escapeHtml(photo.caption || 'Untitled moment')}</b><small>${escapeHtml(photo.date || 'A LITTLE MEMORY')}</small></span></button>`);
    const minSlots = Math.max(0, 4 - photos.length);
    for (let index = 0; index < Math.min(minSlots, 3); index++) {
      cards.push(`<button class="gallery-card add-card" type="button" data-add-memory><span class="add-card-copy"><span class="add-glyph">＋</span><strong>${['A memory goes here', 'A day worth keeping', 'Your next little moment'][index]}</strong><small>ADD YOUR OWN FRAME</small></span></button>`);
    }
    $('#galleryGrid').innerHTML = cards.join('');
    $$('[data-photo-index]').forEach((button) => button.addEventListener('click', () => openLightbox(Number(button.dataset.photoIndex))));
    $$('[data-add-memory]').forEach((button) => button.addEventListener('click', () => openEditor('gallery')));
    if (!photos.length) {
      $('#galleryGrid').innerHTML = '<button class="gallery-card add-card" type="button" data-add-memory><span class="add-card-copy"><span class="add-glyph">＋</span><strong>Add your first memory</strong><small>YOUR PHOTO, YOUR STORY</small></span></button>';
      $('[data-add-memory]')?.addEventListener('click', () => openEditor('gallery'));
    }
  }

  function renderEducationCarousel() {
    const schools = data.education || [];
    const stage = $('#educationCarousel');
    if (!stage) return;
    educationIndex = schools.length ? ((educationIndex % schools.length) + schools.length) % schools.length : 0;
    $('#educationCurrent').textContent = schools.length ? String(educationIndex + 1).padStart(2, '0') : '—';
    $('#educationTotal').textContent = schools.length ? String(schools.length).padStart(2, '0') : '—';
    $('#educationPrev').disabled = schools.length < 2;
    $('#educationNext').disabled = schools.length < 2;
    if (!schools.length) {
      stage.innerHTML = '<div class="education-empty"><div class="education-empty-icon">✳</div><p class="kicker">A STORY STILL BEING WRITTEN</p><h3>My school years,<br><em>one chapter at a time.</em></h3><p>Riwayat pendidikan akan tampil di sini. Login sebagai admin, buka <strong>Edit space → Education</strong>, lalu tambahkan sekolah beserta foto dan tahunnya.</p><span class="education-empty-foot">ADD YOUR CHAPTERS WHEN YOU ARE READY ↗</span></div>';
      $('#educationDots').innerHTML = '';
      return;
    }
    const school = schools[educationIndex] || {};
    const img = school.image || '';
    stage.innerHTML = `<article class="education-feature" data-education-active="${educationIndex}">
      <div class="education-photo ${img ? '' : 'education-photo-placeholder'}">${img ? `<img src="${escapeHtml(img)}" alt="Foto ${escapeHtml(school.school || 'sekolah')}" onerror="this.parentElement.classList.add('education-photo-placeholder');this.remove()" />` : '<div class="school-placeholder-art"><span class="school-art-orbit"></span><span class="school-art-cap">✳</span><small>YOUR SCHOOL PHOTO</small></div>'}<span class="education-photo-tag">${escapeHtml(school.level || 'EDUCATION CHAPTER')}</span></div>
      <div class="education-feature-copy"><div class="education-feature-top"><span class="kicker">A CHAPTER IN MY STORY</span><span class="education-spark">✳</span></div><p class="education-years">${escapeHtml(school.years || 'YEAR — YEAR')}</p><h3>${escapeHtml(school.school || 'Nama sekolah belum diisi')}</h3><p class="education-description">${escapeHtml(school.description || 'Setiap tempat belajar menyimpan pelajaran, teman, dan kenangan yang membentuk versi diriku hari ini.')}</p><div class="education-feature-bottom"><span class="education-step">CHAPTER ${String(educationIndex + 1).padStart(2, '0')}</span><span class="education-step-line"></span><span class="education-total-label">${String(schools.length).padStart(2, '0')} TOTAL</span></div></div>
    </article>`;
    $('#educationDots').innerHTML = schools.map((item, index) => `<button type="button" class="education-dot${index === educationIndex ? ' is-active' : ''}" data-education-dot="${index}" aria-label="Lihat riwayat ${escapeHtml(item.school || `nomor ${index + 1}`)}" aria-current="${index === educationIndex ? 'true' : 'false'}"></button>`).join('');
    $$('[data-education-dot]').forEach((button) => button.addEventListener('click', () => { educationIndex = Number(button.dataset.educationDot); renderEducationCarousel(); }));
  }

  function moveEducation(delta) {
    if (!data.education || data.education.length < 2) return;
    educationIndex = (educationIndex + delta + data.education.length) % data.education.length;
    renderEducationCarousel();
  }

  function renderEditorEducation() {
    const host = $('#editorEducation');
    if (!host || !editorDraft) return;
    const schools = editorDraft.education || [];
    host.innerHTML = schools.map((school, index) => `<article class="editor-school" data-edit-school="${index}">
      <div class="editor-school-head"><span>CHAPTER ${String(index + 1).padStart(2, '0')}</span><button type="button" class="remove-track" data-remove-school="${index}">Remove ×</button></div>
      <div class="editor-school-fields">
        <label>Jenjang pendidikan<select data-school-field="level"><option value="" ${!school.level ? 'selected' : ''}>Pilih jenjang</option>${['PAUD / TK','Sekolah Dasar','Sekolah Menengah Pertama','Sekolah Menengah Atas / Kejuruan','Perguruan Tinggi','Lainnya'].map((level) => `<option value="${escapeHtml(level)}" ${school.level === level ? 'selected' : ''}>${escapeHtml(level)}</option>`).join('')}</select></label>
        <label>Nama sekolah<input data-school-field="school" value="${escapeHtml(school.school || '')}" placeholder="Nama institusi pendidikan" /></label>
        <label>Periode / tahun<input data-school-field="years" value="${escapeHtml(school.years || '')}" placeholder="Contoh: 2019 — 2022" /></label>
        <label class="school-image-url">URL gambar (opsional)<input data-school-field="image" value="${escapeHtml((school.image || '').startsWith('data:') ? '' : (school.image || ''))}" placeholder="https://..." /></label>
        <label class="school-description-field">Cerita singkat<textarea data-school-field="description" rows="2" placeholder="Kenangan, kegiatan, atau hal yang dipelajari…">${escapeHtml(school.description || '')}</textarea></label>
        <label class="school-upload-field">Atau unggah foto<input type="file" data-school-upload="${index}" accept="image/*" /></label>
        <div class="school-image-preview ${school.image ? 'has-image' : ''}">${school.image ? `<img src="${escapeHtml(school.image)}" alt="Pratinjau foto sekolah" />` : '<span>PHOTO PREVIEW</span>'}</div>
      </div></article>`).join('') || '<div class="editor-empty-school"><span>✳</span><strong>Belum ada riwayat pendidikan</strong><p>Mulai dari sekolah yang paling ingin kamu kenang. Tambahkan nama dan foto untuk membuat carousel.</p></div>';
    $$('[data-remove-school]').forEach((button) => button.addEventListener('click', () => {
      collectEditorFields();
      editorDraft.education.splice(Number(button.dataset.removeSchool), 1);
      renderEditorEducation();
    }));
    $$('[data-school-upload]').forEach((input) => input.addEventListener('change', async (event) => {
      const file = event.target.files && event.target.files[0];
      if (!file) return;
      collectEditorFields();
      try {
        const image = await readImageCompressed(file, 1200);
        if (editorDraft.education[Number(input.dataset.schoolUpload)]) editorDraft.education[Number(input.dataset.schoolUpload)].image = image;
        renderEditorEducation();
        $('#editorSaveHint').textContent = 'Foto sekolah siap disimpan.';
      } catch (error) { showToast(error.message || 'Foto sekolah tidak bisa diproses.'); }
    }));
  }

  function applySession(role) {
    sessionRole = role;
    sessionReady = true;
    document.body.classList.toggle('admin-mode', role === 'admin');
    document.body.classList.toggle('guest-mode', role === 'guest');
    document.body.classList.remove('auth-locked');
    $('#authGate').hidden = true;
    $('#openEditor').hidden = role !== 'admin';
    $('#sessionBadge').hidden = false;
    $('#sessionBadge').textContent = role === 'admin' ? 'ADMIN · EXIT ↗' : 'GUEST · EXIT ↗';
    $('#sessionBadge').setAttribute('aria-label', `Keluar dari mode ${role}`);
    if (window.YT && window.YT.Player) setupYouTubePlayer();
    setPlaybackLabel(radioEnabled ? 'TRYING AUTOPLAY…' : 'RADIO OFF · READY', radioEnabled ? 'loading' : 'paused');
  }

  async function enterAsGuest() {
    $('#authMessage').textContent = '';
    try { await fetch('./api/logout', { method: 'POST' }); } catch (_) {}
    applySession('guest');
  }

  async function loginAsAdmin(event) {
    event.preventDefault();
    const email = $('#loginEmail').value.trim();
    const password = $('#loginPassword').value;
    const submit = $('#loginForm').querySelector('button[type="submit"]');
    submit.disabled = true;
    $('#authMessage').classList.remove('is-error');
    $('#authMessage').textContent = 'Memeriksa akun admin…';
    try {
      const response = await fetch('./api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }) });
      const result = await response.json().catch(() => ({}));
      if (!response.ok || !result.ok) {
        const message = [404, 405, 501].includes(response.status)
          ? 'Server admin belum aktif. Jalankan website dengan perintah: node server.js'
          : (result.message || 'Email atau password admin tidak cocok.');
        throw new Error(message);
      }
      $('#loginPassword').value = '';
      $('#authMessage').textContent = '';
      applySession('admin');
    } catch (error) {
      $('#authMessage').classList.add('is-error');
      $('#authMessage').textContent = error.message || 'Tidak dapat terhubung ke server admin. Gunakan Guest atau jalankan node server.js.';
    } finally { submit.disabled = false; }
  }

  async function leaveSession() {
    try { await fetch('./api/logout', { method: 'POST' }); } catch (_) {}
    if (radioEnabled) stopRadio();
    else if (player && ytReady) { try { player.pauseVideo(); } catch (_) {} }
    sessionReady = false;
    sessionRole = null;
    document.body.classList.remove('admin-mode', 'guest-mode');
    document.body.classList.add('auth-locked');
    $('#authGate').hidden = false;
    $('#openEditor').hidden = true;
    $('#sessionBadge').hidden = true;
    $('#authMessage').textContent = '';
    $('#loginPassword').value = '';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function render() {
    renderProfile();
    renderTracks();
    renderGallery();
    renderEducationCarousel();
    updateDockTrack();
    setTrackDisplay();
  }

  function playTrack(index, mode = 'track') {
    if (!data.tracks.length) return;
    selectedIndex = ((index % data.tracks.length) + data.tracks.length) % data.tracks.length;
    playbackMode = mode;
    radioEnabled = true;
    localStorage.removeItem('little-world-radio-off');
    updateDockTrack();
    setPlaybackLabel('CONNECTING TO SOURCE…', 'loading');
    setDockMessage('Menghubungkan ke video musik resmi…', true);
    renderTracks();
    if (!ytReady || !player) {
      showToast('Pemutar sedang terhubung. Jika tidak muncul, buka sumber YouTube melalui panel radio.');
      return;
    }
    const track = data.tracks[selectedIndex];
    const videoId = videoIdFrom(track.source);
    if (videoId) {
      try {
        programmaticLoad = true;
        player.loadVideoById(videoId);
        setTimeout(() => { programmaticLoad = false; }, 900);
        player.playVideo();
      } catch (error) {
        setDockMessage('Sumber belum bisa diputar. Coba buka tautan resmi.', true);
        setPlaybackLabel('SOURCE UNAVAILABLE', 'error');
      }
    } else {
      setDockMessage('Tautan YouTube untuk lagu ini belum diisi. Buka Spotify di bawah.', true);
      setPlaybackLabel('ADD A YOUTUBE LINK', 'error');
    }
  }

  function nextTrack(mode = 'radio') {
    if (!data.tracks.length) return;
    playTrack((selectedIndex + 1) % data.tracks.length, mode);
  }
  function previousTrack() {
    if (!data.tracks.length) return;
    playTrack((selectedIndex - 1 + data.tracks.length) % data.tracks.length, playbackMode);
  }
  function startRadio() {
    radioEnabled = true;
    playbackMode = 'radio';
    localStorage.removeItem('little-world-radio-off');
    setPlaybackLabel('STARTING RADIO…', 'loading');
    setDockMessage('Menyalakan radio. Jika browser memblokir autoplay, tekan Play sekali.', true);
    if (player && ytReady) {
      const track = data.tracks[selectedIndex] || data.tracks[0];
      const videoId = videoIdFrom(track && track.source);
      try {
        if (videoId) player.loadVideoById(videoId);
        player.playVideo();
      } catch (error) { setPlaybackLabel('TAP PLAY TO START', 'blocked'); }
    } else {
      showToast('Radio sedang disiapkan. Tunggu sebentar lalu tekan Play pada panel bawah.');
    }
    setTrackDisplay();
  }
  function stopRadio() {
    radioEnabled = false;
    localStorage.setItem('little-world-radio-off', '1');
    if (player && ytReady) player.pauseVideo();
    playbackState = 'paused';
    setPlaybackLabel('RADIO OFF · PAUSED', 'paused');
    setDockMessage('Radio dimatikan. Aktifkan kembali untuk melanjutkan playlist.', true);
    setTrackDisplay();
  }
  function toggleRadio() { if (radioEnabled) stopRadio(); else startRadio(); }

  function setupYouTubePlayer() {
    if (!sessionReady || !window.YT || !window.YT.Player || ytReady) return;
    try {
      player = new window.YT.Player('youtubePlayer', {
        width: '288', height: '155', videoId: videoIdFrom((data.tracks[0] || {}).source),
        playerVars: { autoplay: 1, controls: 1, playsinline: 1, rel: 0, modestbranding: 1, origin: location.origin === 'null' ? undefined : location.origin },
        events: {
          onReady: function (event) {
            ytReady = true;
            const videoId = videoIdFrom((data.tracks[selectedIndex] || {}).source);
            if (videoId) {
              try { event.target.cueVideoById(videoId); } catch (_) {}
            }
            if (radioEnabled) {
              setPlaybackLabel('TRYING AUTOPLAY…', 'loading');
              setDockMessage('Mencoba menyalakan radio otomatis…', true);
              try { event.target.playVideo(); } catch (_) { setPlaybackLabel('TAP PLAY TO START', 'blocked'); }
            } else {
              setPlaybackLabel('RADIO OFF · READY', 'paused');
              setDockMessage('Radio sedang mati. Tekan RADIO ON untuk mendengarkan.', true);
            }
          },
          onStateChange: function (event) {
            if (!window.YT || !window.YT.PlayerState) return;
            const state = event.data;
            if (state === window.YT.PlayerState.PLAYING) {
              playbackState = 'playing';
              setPlaybackLabel(playbackMode === 'radio' ? 'NOW PLAYING · RADIO LOOP' : 'NOW PLAYING', 'playing');
              setDockMessage('', false);
              setTrackDisplay();
            } else if (state === window.YT.PlayerState.ENDED) {
              if (radioEnabled) nextTrack('radio');
              else { playbackState = 'paused'; setPlaybackLabel('PLAYBACK FINISHED', 'paused'); setTrackDisplay(); }
            } else if (state === window.YT.PlayerState.PAUSED) {
              if (radioEnabled && !programmaticLoad) {
                playbackState = 'paused';
                setPlaybackLabel('KEEPING THE RADIO GOING…', 'paused');
                clearTimeout(pauseFallbackTimer);
                pauseFallbackTimer = setTimeout(() => {
                  if (radioEnabled && player && ytReady && player.getPlayerState() === window.YT.PlayerState.PAUSED) nextTrack('radio');
                }, 1300);
              } else {
                playbackState = 'paused';
                if (!radioEnabled) setPlaybackLabel('RADIO OFF · PAUSED', 'paused');
                setTrackDisplay();
              }
            } else if (state === window.YT.PlayerState.BUFFERING) {
              setPlaybackLabel('BUFFERING…', 'loading');
            }
          },
          onError: function (event) {
            playbackState = 'error';
            setPlaybackLabel('OPEN OFFICIAL SOURCE', 'error');
            setDockMessage('Video tidak tersedia untuk embed ini. Buka tautan sumber atau lanjut ke lagu berikutnya.', true);
            if (radioEnabled) setTimeout(() => { if (radioEnabled) nextTrack('radio'); }, 2500);
            console.warn('YouTube embed error code:', event.data);
          },
          onAutoplayBlocked: function () {
            playbackState = 'blocked';
            setPlaybackLabel('TAP PLAY TO START', 'blocked');
            setDockMessage('Browser memblokir audio otomatis. Tekan Play atau RADIO ON untuk mengaktifkan suara.', true);
            setTrackDisplay();
          }
        }
      });
    } catch (error) {
      console.warn('YouTube player could not start:', error);
      setPlaybackLabel('OPEN OFFICIAL SOURCE', 'error');
      setDockMessage('Pemutar tidak berhasil dimuat. Periksa koneksi internet atau buka sumber resmi.', true);
    }
  }
  window.onYouTubeIframeAPIReady = setupYouTubePlayer;
  if (window.YT && window.YT.Player) setupYouTubePlayer();

  function openTrackDetail(index) {
    const track = data.tracks[index];
    if (!track) return;
    $('#detailCover').src = track.cover || data.profile.photo || './assets/portrait.webp';
    $('#detailCover').alt = `Cover ${track.title}`;
    $('#detailTitle').textContent = track.title || 'Untitled track';
    $('#detailArtist').textContent = `${track.artist || 'Unknown artist'}${track.album ? ` · ${track.album}` : ''}`;
    $('#detailDescription').textContent = track.note || 'Sebuah lagu yang menjadi bagian dari soundtrack personal ini. Putar, simpan, dan nikmati sesuai suasana.';
    const tags = Array.isArray(track.tags) ? track.tags : [track.vibe || 'favorite'];
    $('#detailTags').innerHTML = tags.map((tag) => `<span>${escapeHtml(tag)}</span>`).join('');
    const links = [];
    links.push(`<button class="detail-play" type="button" data-detail-play="${index}">▶ Play this track</button>`);
    if (track.spotify) links.push(`<a href="${escapeHtml(track.spotify)}" target="_blank" rel="noopener noreferrer">Spotify ↗</a>`);
    if (track.source) links.push(`<a href="${escapeHtml(track.source)}" target="_blank" rel="noopener noreferrer">YouTube ↗</a>`);
    $('#detailActions').innerHTML = links.join('');
    $('[data-detail-play]', $('#detailActions')).addEventListener('click', () => { closeModal('trackModal'); playTrack(index, 'track'); });
    openModal('trackModal');
  }

  function openLightbox(index) {
    if (!data.photos.length) return;
    currentLightboxIndex = (index + data.photos.length) % data.photos.length;
    updateLightbox();
    openModal('lightboxModal');
  }
  function updateLightbox() {
    const photo = data.photos[currentLightboxIndex];
    if (!photo) return;
    $('#lightboxImage').src = photo.src;
    $('#lightboxImage').alt = photo.caption || 'Foto personal';
    $('#lightboxCaption').textContent = photo.caption || 'Untitled moment';
    $('#lightboxDate').textContent = photo.date || '';
    $('#lightboxIndex').textContent = `${String(currentLightboxIndex + 1).padStart(2, '0')} / ${String(data.photos.length).padStart(2, '0')}`;
    $('#lightboxPrev').disabled = data.photos.length < 2;
    $('#lightboxNext').disabled = data.photos.length < 2;
  }
  function moveLightbox(delta) { if (data.photos.length) { currentLightboxIndex = (currentLightboxIndex + delta + data.photos.length) % data.photos.length; updateLightbox(); } }
  function openModal(id) { const el = document.getElementById(id); if (!el) return; el.hidden = false; document.body.classList.add('modal-open'); const focusable = $('button:not([disabled]),input,textarea,a[href]', el); setTimeout(() => focusable?.focus({ preventScroll: true }), 30); }
  function closeModal(id) {
    const el = document.getElementById(id);
    if (!el) return;
    el.hidden = true;
    if (!$$('.modal-backdrop').some((modal) => !modal.hidden)) document.body.classList.remove('modal-open');
  }

  function fillEditorProfile() {
    const p = editorDraft.profile;
    $('#editName').value = p.name || '';
    $('#editNickname').value = p.nickname || '';
    $('#editIntro').value = p.intro || '';
    $('#editBio').value = p.bio || '';
    $('#editPrinciple').value = p.principle || '';
    $('#editInterests').value = p.interests || '';
    $('#editCity').value = p.city || '';
    $('#editEmail').value = p.email || '';
    $('#editInstagram').value = p.instagram || '';
    $('#editProfilePhoto').value = '';
  }
  function renderEditorTracks() {
    $('#editorTracks').innerHTML = editorDraft.tracks.map((track, index) => `<article class="editor-track" data-edit-track="${index}"><div class="editor-track-head"><span>TRACK ${String(index + 1).padStart(2, '0')}</span><button type="button" class="remove-track" data-remove-track="${index}">Remove ×</button></div><div class="editor-track-fields">
      <label>Title<input data-track-field="title" value="${escapeHtml(track.title || '')}" required /></label><label>Artist<input data-track-field="artist" value="${escapeHtml(track.artist || '')}" /></label>
      <label>Album / year<input data-track-field="album" value="${escapeHtml(track.album || '')}" /></label><label>Cover image URL<input data-track-field="cover" value="${escapeHtml(track.cover || '')}" /></label>
      <label>Spotify link<input data-track-field="spotify" value="${escapeHtml(track.spotify || '')}" /></label><label>YouTube source link<input data-track-field="source" value="${escapeHtml(track.source || '')}" /></label>
      <label>Short description<textarea data-track-field="note" rows="2">${escapeHtml(track.note || '')}</textarea></label><label>Vibe tags <small>pisahkan dengan koma</small><input data-track-field="tags" value="${escapeHtml((track.tags || []).join(', '))}" /></label>
    </div></article>`).join('');
    $$('[data-remove-track]').forEach((button) => button.addEventListener('click', () => {
      if (editorDraft.tracks.length <= 1) { showToast('Playlist perlu menyisakan setidaknya satu lagu.'); return; }
      editorDraft.tracks.splice(Number(button.dataset.removeTrack), 1);
      renderEditorTracks();
    }));
  }
  function renderEditorPhotos() {
    $('#editorPhotos').innerHTML = (editorDraft.photos || []).map((photo, index) => `<article class="editor-photo" data-edit-photo="${index}"><img src="${escapeHtml(photo.src)}" alt="${escapeHtml(photo.caption || 'Memory')}"/><label class="sr-only">Caption foto ${index + 1}<input data-photo-caption value="${escapeHtml(photo.caption || '')}" aria-label="Caption foto ${index + 1}" placeholder="Caption / moment" /></label><label class="sr-only">Tanggal foto ${index + 1}<input data-photo-date value="${escapeHtml(photo.date || '')}" aria-label="Tanggal foto ${index + 1}" placeholder="Date / year (optional)" /></label><button type="button" data-remove-photo="${index}">Remove photo ×</button></article>`).join('') || '<p class="editor-hint">Belum ada foto di gallery. Unggah satu di atas.</p>';
    $$('[data-remove-photo]').forEach((button) => button.addEventListener('click', () => {
      editorDraft.photos.splice(Number(button.dataset.removePhoto), 1);
      renderEditorPhotos();
    }));
  }
  function openEditor(tab = 'profile') {
    if (sessionRole !== 'admin') { showToast('Fitur edit hanya tersedia untuk akun admin.'); return; }
    editorDraft = clone(data);
    fillEditorProfile();
    renderEditorTracks();
    renderEditorPhotos();
    renderEditorEducation();
    switchEditorTab(tab);
    $('#editorSaveHint').textContent = 'Perubahan belum disimpan.';
    openModal('editorModal');
  }
  function switchEditorTab(tab) {
    $$('.editor-tab').forEach((button) => {
      const active = button.dataset.editorTab === tab;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-selected', String(active));
    });
    $$('.editor-panel').forEach((panel) => panel.classList.toggle('is-active', panel.dataset.editorPanel === tab));
  }
  function collectEditorFields() {
    editorDraft.profile = {
      ...editorDraft.profile,
      name: $('#editName').value.trim() || 'A Little World',
      nickname: $('#editNickname').value.trim(),
      intro: $('#editIntro').value.trim(),
      bio: $('#editBio').value.trim(),
      principle: $('#editPrinciple').value.trim(),
      interests: $('#editInterests').value.trim(),
      city: $('#editCity').value.trim(),
      email: $('#editEmail').value.trim(),
      instagram: $('#editInstagram').value.trim()
    };
    editorDraft.tracks = $$('.editor-track').map((card, index) => {
      const old = editorDraft.tracks[index] || {};
      const get = (field) => $(`[data-track-field="${field}"]`, card)?.value.trim() || '';
      return { ...old, title: get('title') || 'Untitled track', artist: get('artist'), album: get('album'), cover: get('cover'), spotify: get('spotify'), source: get('source'), note: get('note'), tags: get('tags').split(',').map((v) => v.trim()).filter(Boolean), vibe: get('tags').split(',')[0].trim().toUpperCase() };
    });
    editorDraft.photos = $$('.editor-photo').map((card, index) => ({
      ...editorDraft.photos[index], caption: $('[data-photo-caption]', card).value.trim(), date: $('[data-photo-date]', card).value.trim()
    }));
    editorDraft.education = $$('.editor-school').map((card, index) => {
      const old = (editorDraft.education || [])[index] || {};
      const get = (field) => $(`[data-school-field="${field}"]`, card)?.value.trim() || '';
      return { ...old, level: get('level'), school: get('school'), years: get('years'), description: get('description'), image: get('image') || old.image || '' };
    });
    return editorDraft;
  }
  async function saveEditor() {
    if (sessionRole !== 'admin') { showToast('Akun admin diperlukan untuk menyimpan perubahan.'); return; }
    collectEditorFields();
    if (!editorDraft.tracks.length) { showToast('Tambahkan minimal satu lagu ke playlist.'); return; }
    data = normalizeData(editorDraft);
    selectedIndex = Math.min(selectedIndex, Math.max(0, data.tracks.length - 1));
    render();
    const localSaved = saveToLocal();
    let savedOnServer = false;
    let expiredAdminSession = false;
    try {
      const response = await fetch('./api/content', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
      if (response.ok) savedOnServer = true;
      else if (response.status === 401 || response.status === 403) expiredAdminSession = true;
    } catch (_) { /* Offline/static preview still keeps a local copy. */ }
    if (expiredAdminSession) {
      closeModal('editorModal');
      await leaveSession();
      showToast('Sesi admin tidak berlaku. Silakan login kembali.');
      return;
    }
    if (player && ytReady && radioEnabled) {
      const videoId = videoIdFrom((data.tracks[selectedIndex] || {}).source);
      if (videoId) { try { player.loadVideoById(videoId); player.playVideo(); } catch (_) {} }
    }
    closeModal('editorModal');
    if (savedOnServer) showToast('Berhasil disimpan ke website. Pengunjung akan melihat konten terbaru.');
    else if (localSaved) showToast('Tersimpan di browser ini. Untuk menyimpan ke website bersama, jalankan node server.js.');
    else showToast('Perubahan siap untuk sesi ini, tetapi browser kehabisan ruang penyimpanan.');
  }

  function readImageCompressed(file, maxDimension = 1500) {
    return new Promise((resolve, reject) => {
      if (!file || !file.type.startsWith('image/')) return reject(new Error('Pilih file gambar yang valid.'));
      const reader = new FileReader();
      reader.onerror = () => reject(new Error('Foto gagal dibaca.'));
      reader.onload = () => {
        const image = new Image();
        image.onerror = () => reject(new Error('Foto tidak dapat dibuka.'));
        image.onload = () => {
          const scale = Math.min(1, maxDimension / Math.max(image.naturalWidth, image.naturalHeight));
          const canvas = document.createElement('canvas');
          canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
          canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
          const context = canvas.getContext('2d');
          context.drawImage(image, 0, 0, canvas.width, canvas.height);
          try { resolve(canvas.toDataURL('image/webp', .82)); }
          catch (_) { resolve(String(reader.result)); }
        };
        image.src = String(reader.result);
      };
      reader.readAsDataURL(file);
    });
  }
  function downloadJSON(obj, filename = 'little-world-content.json') {
    const blob = new Blob([JSON.stringify(obj, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function setupNavigation() {
    const sections = $$('[data-slide]');
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting && entry.intersectionRatio >= .28) {
          activeSlide = entry.target.id;
          $$('.nav-link').forEach((link) => link.classList.toggle('is-active', link.dataset.nav === activeSlide));
          $$('.rail-dot').forEach((link) => link.classList.toggle('is-active', link.dataset.rail === activeSlide));
          $('#currentSlideNumber').textContent = String(sections.findIndex((section) => section.id === activeSlide) + 1).padStart(2, '0');
          entry.target.querySelectorAll('.reveal').forEach((el) => el.classList.add('visible'));
        }
      });
    }, { threshold: [.28, .5, .72] });
    sections.forEach((section) => observer.observe(section));
    const updateProgress = () => {
      const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
      $('#readProgress').style.transform = `scaleX(${maxScroll > 0 ? Math.min(1, window.scrollY / maxScroll) : 0})`;
    };
    window.addEventListener('scroll', updateProgress, { passive: true });
    updateProgress();
    $$('.nav-link').forEach((link) => link.addEventListener('click', () => $('.main-nav').classList.remove('is-open')));
    $('#mobileMenuToggle').addEventListener('click', () => {
      const menu = $('.main-nav');
      const open = menu.classList.toggle('is-open');
      $('#mobileMenuToggle').setAttribute('aria-expanded', String(open));
      $('#mobileMenuToggle').querySelector('span').textContent = open ? '×' : '☰';
    });
    document.addEventListener('keydown', (event) => {
      const modalOpen = $$('.modal-backdrop').some((modal) => !modal.hidden);
      if (event.key === 'Escape' && modalOpen) {
        $$('.modal-backdrop').forEach((modal) => { if (!modal.hidden) closeModal(modal.id); });
        return;
      }
      if (!$('#lightboxModal').hidden && event.key === 'ArrowLeft') { moveLightbox(-1); return; }
      if (!$('#lightboxModal').hidden && event.key === 'ArrowRight') { moveLightbox(1); return; }
      const tag = document.activeElement && document.activeElement.tagName;
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(tag) || document.activeElement?.isContentEditable || modalOpen) return;
      if (event.key === 'ArrowDown' || event.key === 'PageDown') {
        event.preventDefault();
        const index = sections.findIndex((section) => section.id === activeSlide);
        sections[Math.min(sections.length - 1, index + 1)]?.scrollIntoView({ behavior: 'smooth' });
      }
      if (event.key === 'ArrowUp' || event.key === 'PageUp') {
        event.preventDefault();
        const index = sections.findIndex((section) => section.id === activeSlide);
        sections[Math.max(0, index - 1)]?.scrollIntoView({ behavior: 'smooth' });
      }
      if (event.key.toLowerCase() === 'm') toggleRadio();
    });
  }

  function setupEvents() {
    $('#loginForm').addEventListener('submit', loginAsAdmin);
    $('#guestAccess').addEventListener('click', enterAsGuest);
    $('#sessionBadge').addEventListener('click', leaveSession);
    $('#togglePassword').addEventListener('click', () => {
      const field = $('#loginPassword');
      const visible = field.type === 'password';
      field.type = visible ? 'text' : 'password';
      $('#togglePassword').setAttribute('aria-label', visible ? 'Sembunyikan password' : 'Tampilkan password');
      $('#togglePassword').textContent = visible ? '◎' : '◉';
    });
    $('#educationPrev').addEventListener('click', () => moveEducation(-1));
    $('#educationNext').addEventListener('click', () => moveEducation(1));
    $('#educationCarousel').addEventListener('pointerenter', () => { educationPaused = true; });
    $('#educationCarousel').addEventListener('pointerleave', () => { educationPaused = false; });
    $('#educationCarousel').addEventListener('focusin', () => { educationPaused = true; });
    $('#educationCarousel').addEventListener('focusout', () => { educationPaused = false; });
    document.addEventListener('visibilitychange', () => { if (document.hidden) educationPaused = true; else educationPaused = false; });
    window.setInterval(() => {
      const reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (sessionReady && activeSlide === 'education' && !educationPaused && !document.hidden && !reducedMotion && (data.education || []).length > 1) moveEducation(1);
    }, 5600);
    $('#themeToggle').addEventListener('click', () => {
      const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
      document.documentElement.dataset.theme = next;
      localStorage.setItem('little-world-theme', next);
      $('#themeGlyph').textContent = next === 'dark' ? '☼' : '☾';
    });
    const theme = localStorage.getItem('little-world-theme');
    if (theme === 'light' || theme === 'dark') document.documentElement.dataset.theme = theme;
    $('#themeGlyph').textContent = document.documentElement.dataset.theme === 'dark' ? '☼' : '☾';
    $('#soundToggle').addEventListener('click', toggleRadio);
    $('#heroRadioStart').addEventListener('click', startRadio);
    $('#playAllTracks').addEventListener('click', () => playTrack(0, 'radio'));
    $('#dockPlay').addEventListener('click', () => {
      if (!player || !ytReady) { startRadio(); return; }
      if (playbackState === 'playing' && player.getPlayerState && player.getPlayerState() === window.YT.PlayerState.PLAYING) {
        if (radioEnabled) { stopRadio(); } else { player.pauseVideo(); }
      } else { radioEnabled = true; localStorage.removeItem('little-world-radio-off'); try { player.playVideo(); } catch (_) {} setPlaybackLabel('STARTING…', 'loading'); }
    });
    $('#dockNext').addEventListener('click', () => nextTrack(playbackMode));
    $('#dockPrev').addEventListener('click', previousTrack);
    $('#dockToggle').addEventListener('click', () => {
      const dock = $('#radioDock');
      const collapsed = dock.classList.toggle('is-collapsed');
      $('#dockToggle').setAttribute('aria-expanded', String(!collapsed));
      $('#dockToggle').setAttribute('aria-label', collapsed ? 'Buka panel informasi radio' : 'Kecilkan panel informasi radio');
      $('#dockToggle').textContent = collapsed ? '+' : '−';
    });
    $('#openEditor').addEventListener('click', () => openEditor('profile'));
    $('#galleryAddButton').addEventListener('click', () => openEditor('gallery'));
    $('#trackSearch').addEventListener('input', renderTracks);
    $('#lightboxPrev').addEventListener('click', () => moveLightbox(-1));
    $('#lightboxNext').addEventListener('click', () => moveLightbox(1));
    $$('.modal-close').forEach((button) => button.addEventListener('click', () => closeModal(button.dataset.close || button.closest('.modal-backdrop').id)));
    $$('.modal-backdrop').forEach((backdrop) => backdrop.addEventListener('click', (event) => { if (event.target === backdrop) closeModal(backdrop.id); }));
    $$('.editor-tab').forEach((button) => button.addEventListener('click', () => switchEditorTab(button.dataset.editorTab)));
    $$('[data-close="editorModal"]').forEach((button) => button.addEventListener('click', () => closeModal('editorModal')));
    $('#saveEditor').addEventListener('click', saveEditor);
    $('#addSchool').addEventListener('click', () => {
      if (sessionRole !== 'admin') return;
      if (!editorDraft) editorDraft = clone(data);
      collectEditorFields();
      editorDraft.education.push({ id: `school-${Date.now()}`, level: '', school: '', years: '', description: '', image: '' });
      renderEditorEducation();
      $('#editorSaveHint').textContent = 'Riwayat baru ditambahkan. Lengkapi detailnya lalu simpan.';
    });
    $('#addTrack').addEventListener('click', () => {
      if (!editorDraft) editorDraft = clone(data);
      editorDraft.tracks.push({ id: `track-new-${Date.now()}`, title: '', artist: '', album: '', cover: '', spotify: '', source: '', note: '', vibe: 'FAVORITE', tags: ['favorite'] });
      renderEditorTracks();
    });
    $('#editProfilePhoto').addEventListener('change', async (event) => {
      const file = event.target.files && event.target.files[0];
      if (!file || !editorDraft) return;
      try { editorDraft.profile.photo = await readImageCompressed(file); $('#editorSaveHint').textContent = 'Foto profil baru siap disimpan.'; }
      catch (error) { showToast(error.message || 'Foto tidak bisa diproses.'); }
    });
    $('#addPhotosInput').addEventListener('change', async (event) => {
      const files = Array.from(event.target.files || []);
      if (!editorDraft || !files.length) return;
      for (const file of files) {
        try {
          const src = await readImageCompressed(file);
          editorDraft.photos.push({ id: `photo-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, src, caption: file.name.replace(/\.[^.]+$/, ''), date: '', shape: 'portrait' });
        } catch (error) { showToast(error.message || `Gagal membaca ${file.name}.`); }
      }
      renderEditorPhotos();
      event.target.value = '';
      $('#editorSaveHint').textContent = `${files.length} foto siap disimpan.`;
    });
    $('#exportData').addEventListener('click', () => { if (sessionRole === 'admin') downloadJSON(data); });
    $('#importData').addEventListener('change', async (event) => {
      const file = event.target.files && event.target.files[0];
      if (!file) return;
      try {
        const text = await file.text();
        editorDraft = normalizeData(JSON.parse(text));
        fillEditorProfile(); renderEditorTracks(); renderEditorPhotos(); renderEditorEducation();
        $('#editorSaveHint').textContent = 'Konfigurasi dimuat. Tekan Save changes untuk menerapkannya.';
        showToast('Konfigurasi diimpor. Simpan perubahan untuk menerapkan.');
      } catch (_) { showToast('File JSON tidak valid atau tidak dapat dibaca.'); }
      event.target.value = '';
    });
    $('#resetData').addEventListener('click', () => {
      if (!window.confirm('Kembalikan konten ke versi original? Perubahan yang belum diekspor akan diganti.')) return;
      editorDraft = clone(baseData);
      fillEditorProfile(); renderEditorTracks(); renderEditorPhotos(); renderEditorEducation();
      $('#editorSaveHint').textContent = 'Konten awal dipulihkan di editor. Tekan Save changes untuk menerapkan.';
    });
    $('#messageForm').addEventListener('submit', (event) => {
      event.preventDefault();
      const p = data.profile;
      if (!p.email) {
        showToast('Alamat email belum disetel. Tambahkan melalui Edit space.');
        openEditor('profile');
        return;
      }
      const name = $('#senderName').value.trim();
      const email = $('#senderEmail').value.trim();
      const message = $('#senderMessage').value.trim();
      const subject = `Hello from ${name || 'a visitor'} — A Little World`;
      const body = `${message}\n\n— ${name || 'Visitor'}${email ? `\nReply to: ${email}` : ''}`;
      window.location.href = `mailto:${encodeURIComponent(p.email)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      showToast('Aplikasi email dibuka untuk menyiapkan pesan.');
    });
    $('#lightboxModal').addEventListener('keydown', (event) => {
      if (event.key === 'ArrowLeft') moveLightbox(-1);
      if (event.key === 'ArrowRight') moveLightbox(1);
    });
  }

  async function loadData() {
    let fromFile = null;
    try {
      const response = await fetch('./api/content', { cache: 'no-store' });
      if (response.ok) fromFile = await response.json();
    } catch (_) { /* Opening index.html directly may block fetch; inline defaults still work. */ }
    let fromStorage = null;
    try {
      const stored = localStorage.getItem('little-world-content-v2');
      if (stored) fromStorage = JSON.parse(stored);
    } catch (error) { console.warn('Saved content could not be parsed:', error); }
    let serverAvailable = false;
    try {
      const response = await fetch('./api/session', { cache: 'no-store' });
      const sessionInfo = await response.json();
      serverAvailable = response.ok && typeof sessionInfo.authenticated === 'boolean';
    } catch (_) { /* Static preview has no API; use the local browser copy. */ }
    data = normalizeData((serverAvailable && fromFile) ? fromFile : (fromStorage || fromFile || defaultData));
    baseData = normalizeData(fromFile || defaultData);
    selectedIndex = 0;
    render();
  }

  async function init() {
    await loadData();
    setupEvents();
    setupNavigation();
    setPlaybackLabel(radioEnabled ? 'TRYING AUTOPLAY…' : 'RADIO OFF · READY', radioEnabled ? 'loading' : 'paused');
    if (!radioEnabled) setDockMessage('Radio sedang mati. Tekan RADIO ON untuk mendengarkan.', true);
    // If the iframe API has not arrived yet, its global callback will initialize it later.
    // The player remains idle until the visitor chooses Guest or signs in as Admin.
    // Reveal initial-slide details even before the first observer callback.
    $('#home').querySelectorAll('.reveal').forEach((el) => el.classList.add('visible'));
  }

  init().catch((error) => {
    console.error('Website initialization failed:', error);
    showToast('Ada bagian website yang gagal dimuat. Muat ulang halaman untuk mencoba kembali.');
  });
})();
